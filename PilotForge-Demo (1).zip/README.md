# PilotForge — Tax Incentive Intelligence Platform
## Demo Setup Guide

---

### What you need

- **Docker Desktop** (free) — [docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop)
- Windows 10/11, macOS, or Linux
- ~2 GB disk space for images
- Internet connection for first-time setup (images download automatically)

---

### Start the demo (Windows)

1. Make sure Docker Desktop is running (look for the whale icon in your taskbar)
2. Double-click **`start.ps1`** → right-click → **Run with PowerShell**
3. The dashboard opens automatically at `http://localhost:3000`

**Login credentials:**
| Field | Value |
|---|---|
| Email | `admin@pilotforge.com` |
| Password | `pilotforge2024` |

---

### Start the demo (Mac / Linux)

Open a terminal in this folder and run:

```bash
docker compose up -d
```

Then open [http://localhost:3000](http://localhost:3000) in your browser.

---

### Stop the demo

**Windows:** Double-click `stop.ps1` → Run with PowerShell

**Mac/Linux:**
```bash
docker compose down
```

Your data is preserved between sessions. To wipe all data and start fresh:
```bash
docker compose down -v
```

---

### What's included

| Feature | Description |
|---|---|
| **Executive Dashboard** | Budget volume, estimated credits, active projects |
| **Productions** | Create and manage film/TV productions |
| **Incentive Calculator** | Real-time credit calculation across all jurisdictions |
| **Jurisdiction Intelligence** | 39 jurisdictions — USA, Canada, UK, EU, AU, NZ |
| **AI Advisor** | Chat interface for jurisdiction comparisons and strategy |
| **MMB Connector** | Cast & crew member data import |
| **Regulatory Feed** | Live monitoring of incentive program changes |

**Jurisdictions covered:** CA, GA, NY, LA, NM, IL, MI, NJ, VA, CO, HI, OR, MT, MS, BC, ON, QC, UK, AU, IE, FR, ES, NZ + 16 additional US states

---

### Troubleshooting

**"Docker is not running"** — Open Docker Desktop from the Start Menu and wait ~30 seconds for it to fully load, then try again.

**Dashboard shows blank page** — Wait 30 more seconds and refresh. The backend takes ~20s to initialize on first run.

**Port 3000 already in use** — Something else is using port 3000 on your machine. Stop that application or contact your PilotForge representative.

---

*PilotForge · Tax Incentive Intelligence for Film & TV Production*
